import java.util.Scanner;

public class build_tree_from_traversal_pairs {            // main class starts from here
		
		public static void main(String args[]) {        // main function starts from here
			
			String s1;          // String which stores the name of first input traversal
			String s2;         // String which stores the name of first input traversal
			int n1;           // Integer which stores the number of elements in first input traversal sequence
			int n2;          // Integer which stores the number of elements in second input traversal sequence
			
			Scanner input = new Scanner(System.in);  // expression to take input from the system
			
			s1 = input.next();                     // taking input the name of first input traversal
			s1 = s1.toLowerCase();                // converting the name of first input traversal to lower case
			n1 = input.nextInt();                // taking input the number of elements in first input traversal sequence
			String[] c1 = new String[n1];
			for (int i=0; i<n1; i++)
				c1[i] = input.next();         // taking input the elements of first input traversal sequence
			
			s2 = input.next();                    // taking input the name of second input traversal
			s2 = s2.toLowerCase();               // converting the name of second input traversal to lower case
			n2 = input.nextInt();               // taking input the number of elements in second input traversal sequence
			String[] c2 = new String[n2];
			for (int i=0; i<n2; i++)
				c2[i] = input.next();        // taking input the elements of first input traversal sequence
			
		    if (n1!=n2)                    /* checking condition if the number of elements in first input traversal sequence
		                                    is not the same as the number of elements in second input traversal sequence */
		    	
				System.out.println("error: Binary tree cannot be constructed"); // if true then code terminates here with a message display
			
			else{                // if false then code continues further
			
				String[] preorder = new String[n1];           // creating an array named preorder of length n1
				String[] postorder = new String[n1];         // creating an array named postorder of length n1
				String[] inorder = new String[n1];          // creating an array named inorder of length n1
				
				for(int j=0; j<n1; j++) {                  
					boolean temp = false;
					for(int k=0; k<n2; k++) {
						if (c2[k].equals(c1[j])) {         // checking if each element of first input traversal sequence is in second input traversal sequence */
							temp = true;                  // if true then code continues further
						}
					}
						if (temp == false) {
							System.out.println("error: Binary tree cannot be built from the input sequence"); // if false then code terminates here with a display message
							System.exit(0);                                                                  // terminating the code here after checking the former condition
						}
				}
				
				
			if (s1.equals("preorder"))                 // checking if the name of first input traversal is pre-order
				for (int i=0; i<n1; i++)
					preorder[i] = c1[i];             // if true then pre-order array is filled with the elements of first input traversal sequence
			
			else if(s1.equals("postorder"))        // checking if the name of first input traversal is post-order
				for (int i=0; i<n1; i++)
					postorder[i] = c1[i];        // if true then post-order array is filled with the elements of first input traversal sequence
			
			else if(s1.equals("inorder"))      // checking if the name of first input traversal is in-order
				for (int i=0; i<n1; i++)
					inorder[i] = c1[i];      // if true then in-order array is filled with the elements of first input traversal sequence
			
			else {
				System.out.println("error: Input order cannot be considered");    // if none of the above conditions falls true then code terminates here with an output display
				System.exit(0);                                                  // terminating the code here after checking the former condition
			    }
			
			//First if//
			if (s2.equals("preorder"))                  // checking if the name of second input traversal is pre-order
				for (int i=0; i<n2; i++)
					preorder[i] = c2[i];              // if true then pre-order array is filled with the elements of second input traversal sequence
		
			else if(s2.equals("postorder"))         // checking if the name of second input traversal is post-order
				for (int i=0; i<n2; i++)
					postorder[i] = c2[i];         // if true then post-order array is filled with the elements of second input traversal sequence
			
			else if(s2.equals("inorder"))       // checking if the name of second input traversal is in-order
				for (int i=0; i<n2; i++)
					inorder[i] = c2[i];       // if true then in-order array is filled with the elements of second input traversal sequence
			
			else {                             
			System.out.println("error: Input order cannot be considered");   // if none of the above conditions falls true then code terminates here with an output display
			System.exit(0);                                                 // terminating the code here after checking the former condition
			}
			
			
			/* checking 
			 * if the name of first input traversal is pre-order & the name of second input traversal is in-order 
			 * or 
			 * if the name of first input traversal is in-order & the name of second input traversal is pre-order 
			 * */
			if ( ( s1.equals("preorder") && s2.equals("inorder") ) || ( s1.equals("inorder") && s2.equals("preorder") ) ) {
				
				try {                                                // try-catch in order to try  building of tree
					
				Preorder_Inorder_buildTree(preorder, inorder);     // calling a function to build the tree from pre-order and in-order traversal
				for(int i=0;i<terminate;i++)
					System.out.println(D[i]);                    // printing the required saved output
				
				} catch(Exception e){                          // catching if any error occurs while building the tree
					System.out.println("error: Tree cannot be constructed using these two traversals");    // if yes then an error display is set up
				}
				catch(StackOverflowError e) {
					System.out.println("error: Tree cannot be constructed using these two traversals");    // if yes then an error display is set up
				}
				
			}
			
			
			/* checking 
			 * if the name of first input traversal is post-order & the name of second input traversal is in-order 
			 * or 
			 * if the name of first input traversal is in-order & the name of second input traversal is post-order 
			 * */
			else if ( ( s1.equals("postorder") && s2.equals("inorder") ) || ( s1.equals("inorder") && s2.equals("postorder") ) ) {
				
				try{                                                 // try-catch in order to try  building of tree
					
				Postorder_Inorder_buildTree(inorder, postorder);   // calling a function to build the tree from post-order and in-order traversal
				for(int i=0;i<terminate;i++)
					System.out.println(D[i]);                    // printing the required saved output
				
			    } catch(Exception e){                          // catching if any error occurs while building the tree
				       System.out.println("error: Tree cannot be constructed using these two traversals");   // if yes then an error display is set up
			    }
				catch(StackOverflowError e) {
					System.out.println("error: Tree cannot be constructed using these two traversals");    // if yes then an error display is set up
				}
				
			}
			
			
			/* checking 
			 * if the name of first input traversal is pre-order & the name of second input traversal is post-order 
			 * or 
			 * if the name of first input traversal is post-order & the name of second input traversal is pre-order 
			 * */
			else if ( ( s1.equals("preorder") && s2.equals("postorder") ) || ( s1.equals("postorder") && s2.equals("preorder") ) ) {
				
				try{                                                       // try-catch in order to try  building of tree
					
					Preorder_Postorder_buildTree(preorder, postorder);   // calling a function to build the tree from pre-order and post-order traversal
					for(int i=0;i<terminate;i++)
						System.out.println(D[i]);                      // printing the required saved output
					
			    } catch(Exception e){                                // catching if any error occurs while building the tree
				       System.out.println("error: Tree cannot be constructed using these two traversals");    // if yes then an error display is set up
			    }
				catch(StackOverflowError e) {
					System.out.println("error: Tree cannot be constructed using these two traversals");    // if yes then an error display is set up
				}
				
			}
			
			
			/* if none of the above condition falls true
			 * then
			 * an output message is displayed and the code terminated here  */
			else
				System.out.println("Following combination of input traversal is not allowed");
			
			}

		}
		
		public static int length = 0;
		
		private static String D[]=new String[10000];      // an array of String  with enough space to store the elements to be printed(below)
		private static int terminate=0;                  // an initialized integer used below in saving the elements to be printed as required
		
		/* building tree using Pre-order / In-order
		 * function starts from here */
		public static void Preorder_Inorder_buildTree(String[] preorder, String[] inorder) {
	  	    int preFirst = 0;                               // index of first element of array preorder
	  	    int preLast = preorder.length-1;               // index of last element of array preorder
	  	    int inFirst = 0;                              // index of first element of array inorder
	  	    int inLast = inorder.length-1;               // index of last element of array inorder
	  	    construct("root",0,preorder, preFirst, preLast, inorder, inFirst, inLast);     // calling a recursive function which internally build the tree
	  	}
		/* recursive function which internally build the tree */
	  	public static tNode construct(String s,int k,String[] preorder, int preFirst, int preLast, String[] inorder, int inFirst, int inLast){
	  	    
	  		if(length >500) {
				System.out.println("error: Tree cannot be constructed using these two traversals");
				System.exit(0);
            }
			length++;
	  		
	  		if(preFirst>preLast||inFirst>inLast){                  // termination condition for the recursion
	  	        return null;
	  	    }
	  		
	  	    String parentData = preorder[preFirst];            // saving the data of parent node of a tree or its sub-tree
	  	    tNode parent = new tNode(parentData);
	  	   
	  	    //find parent element index from inorder
	  	    int temp=0;
	  	    for(int i=0; i<inorder.length; i++){           // loop which checks the parentData of preorder in inorder  
	  	    	
	  	        if(inorder[i].equals( parentData)){
	  	            temp=i;                              // if it is found then the loop is stopped and the corresponding index is saved
	  	            break;
	  	        }
	  	        
	  	    }
	  	    
	  	    String s1="";
	  	    for(int i=0;i<k;i++)                  // loop which saves the output display of tree if no error is caught till the end
	  	    	s1+="\t";
	  	    s1+="("+s+", "+parent.data+")";
	  	 D[terminate]=s1;
	  	 terminate++;
	  	   
	  	   /* building all the left child via recursion  */
	  	   parent.left_child = construct("left",k+1,preorder, preFirst+1, preFirst+(temp-inFirst), inorder, inFirst, temp-1);
	  	   
	  	   /* building all the right child via recursion  */
	  	   parent.right_child= construct("right",k+1,preorder, preFirst+(temp-inFirst)+1, preLast, inorder, temp+1 , inLast);
	  	    
	  	    return parent;
	  	}

	  	
	  	/* building tree using Post-order / In-order
		 * function starts from here */
		public static void Postorder_Inorder_buildTree(String[] inorder, String[] postorder) {
			int inFirst = 0;                                // index of first element of array inorder
			int inLast = inorder.length - 1;               // index of last element of array inorder
			int postFirst = 0;                            // index of first element of array postorder
			int postLast = postorder.length - 1;         // index of last element of array postorder
			constructTree("root",0,inorder, inFirst, inLast, postorder, postFirst, postLast);     // calling a recursive function which internally build the tree
		}
		/* recursive function which internally build the tree */
		public static tNode constructTree(String s,int k,String[] inorder, int inFirst, int inLast, String[] postorder, int postFirst, int postLast) {
			
			if(length >500) {
				System.out.println("error: Tree cannot be constructed using these two traversals");
				System.exit(0);
            }
			length++;
			
			if (inFirst > inLast || postFirst > postLast)                 // termination condition for the recursion
				return null;
		 
			String parentData = postorder[postLast];                   // saving the data of parent node of a tree or its sub-tree
			tNode parent = new tNode(parentData);
		 
			int temp = 0;
			for (int i = 0; i < inorder.length; i++) {             // loop which checks the parentData of postorder in inorder
				
				if (inorder[i].equals(parentData)) {               
					temp = i;                                   // if it is found then the loop is stopped and the corresponding index is saved
					break;
				}
				
			}
		 
	  	    String s1="";                                // loop which saves the output display of tree if no error is caught till the end
	  	    for(int i=0;i<k;i++)
	  	    	s1+="\t";
	  	    s1+="("+s+", "+parent.data+")";
	  	 D[terminate]=s1;
	  	 terminate++;
			
	  	    /* building all the left child via recursion  */
			parent.left_child = constructTree("left",k+1,inorder, inFirst, temp - 1, postorder, postFirst, postFirst + temp - (inFirst + 1));
			
			/* building all the right child via recursion  */
			parent.right_child = constructTree("right",k+1,inorder, temp + 1, inLast, postorder, postFirst + temp- inFirst, postLast - 1);
		 
			return parent;
		}
		
		
		/* building tree using Pre-order / Post-order
		 * function starts from here */
		public static void Preorder_Postorder_buildTree(String[] preorder, String[] postorder) {
		    int preFirst = 0;
		    int preLast = preorder.length-1;
		    int postFirst = 0;
		    int postLast = postorder.length-1;
		    
		    constructBinaryTree( "root", 0, preorder, preFirst, preLast, postorder, postFirst, postLast);
		}
		
		public static tNode constructBinaryTree( String s, int k, String[] preorder, int preFirst, int preLast, String[] postorder, int postFirst, int postLast){
			
			String rootData = preorder[preFirst];                                   // saving the data of root node of a tree or its sub-tree
			
			if(length >500) {
				System.out.println("error: Tree cannot be constructed using these two traversals");
				System.exit(0);
            }
			length++;
			
			/* condition which checks if the unique tree can be built using preorder and postorder
			 * If yes, then code continues without entering inside this condition
			 * If no, then the code is terminated with an output display
			 */
            if(length >preorder.length-1) {
				System.out.println("error: Tree cannot be constructed using these two traversals");
				System.exit(0);
            }
			length++;
			
			String s1="";                                                         // loop which saves the output display of tree if no error is caught till the end
	  	    for(int j=0;j<k;j++)
	  	    	s1+="\t";
	  	    s1+="("+s+", "+rootData+")";
	  	 D[terminate]=s1;
	  	 terminate++;

			
			if(preFirst>=preLast||postFirst>=postLast){                  // termination condition for the recursion
		        return null;
		    }
		 
		    String parentData = preorder[preFirst+1];                // saving the data of parent node of a tree or its sub-tree
		    tNode parent = new tNode(parentData);
		    
		    int temp=0;
		    for(int i=0; i<postorder.length; i++) {              // loop which checks the parentData of preorder is in postorder
		    	
		        if(postorder[i].equals(parentData)) {
		            temp=i;                                   // if it is found then the loop is stopped and the corresponding index is saved
		            break;
		        }
		    }
		    
		    /* building all the left child via recursion  */
		    parent.left_child = constructBinaryTree("left", k+1, preorder, preFirst+1, preFirst+temp+1-postFirst, postorder, postFirst, temp);
		    /* building all the right child via recursion  */
		    parent.right_child= constructBinaryTree( "right", k+1, preorder, preFirst+temp+2-postFirst, preLast, postorder, temp+1, postLast-1);
		    
			return parent;
}
}


/*  A class 'node' which stores 
 * 1. a reference to a node
 * 2. the data in the node
 * 3. a reference to the left child of a particular node
 * 4. a reference to the right child of a particular node 
 * 
 * code starts from here 
 * */
class tNode {
	String data;
	
	tNode left_child;           // saving a reference to the left child of a particular node
	tNode right_child;         // saving a reference to the right child of a particular node
	
	tNode(String data) {     // constructor of this class
		this.data = data;   // saving the data in a particular node
	}
}